<template>
  <div>
    <h1>{{mensagem}}</h1>
  </div>
</template>
<script>

export default {
  name:"Dashboard",
  data(){
    return {
      mensagem: "Estou na tela de dashboard"
    }
  }
}
</script>
<style scoped>

</style>
